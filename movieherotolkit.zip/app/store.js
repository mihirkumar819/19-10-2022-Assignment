const configureStore=require("@reduxjs/toolkit").configureStore;
const movieReducer=require("../features/movie/movieslice");
const heroReducer=require("../features/hero/heroslice");

const store=configureStore({
    reducer:{
        movie:movieReducer,
        hero:heroReducer
    }
});
module.exports=store;